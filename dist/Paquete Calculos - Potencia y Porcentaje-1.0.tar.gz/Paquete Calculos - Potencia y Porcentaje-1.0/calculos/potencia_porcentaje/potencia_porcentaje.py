def op_potencia(base, exponente):
    print(f'El resultado de la potencia es: {base ** exponente}')
    
def op_porcentaje(num1, num2):
    porcentaje = (num1 * num2) / 100
    total = num1 - porcentaje
    print(f'El resultado del porcentaje es: {total}')