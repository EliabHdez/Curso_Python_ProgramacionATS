def suma(num1, num2):
    print(f'El resultado de la suma es: {num1 + num2}')
    
def resta(num1, num2):
    print(f'El resultado de la resta es: {num1 - num2}')
    
def multiplicacion(num1, num2):
    print(f'El resultado de la multiplicacion es: {num1 * num2}')
    
def division(num1, num2):
    print(f'El resultado de la division es: {num1 / num2}')
    
def potencia(base, exponente):
    print(f'El resultado de la potencia es: {base ** exponente}')
    
def porcentaje(num1, num2):
    porcentaje = (num1 * num2) / 100
    total = num1 - porcentaje
    print(f'El resultado del porcentaje es: {total}')
    
def redondeo(numero):
    print(f'El resultado del redondeo es: {round(numero)}')